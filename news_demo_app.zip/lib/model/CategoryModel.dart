class CategoryModel{
  String categoryName;
  String imageUrl;
}